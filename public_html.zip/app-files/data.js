var APP_DATA = {
    "scenes": [{
            "id": "0-entrance",
            "name": "Entrance",
            "mapcontainer": "1",
            "x": "45%",
            "y": "10%",
            "videos": false,
            "levels": [{
                    "tileSize": 256,
                    "size": 256,
                    "fallbackOnly": true
                },
                {
                    "tileSize": 512,
                    "size": 512
                },
                {
                    "tileSize": 512,
                    "size": 1024
                },
                {
                    "tileSize": 512,
                    "size": 2048
                }
            ],
            "faceSize": 2048,
            "initialViewParameters": {
                "yaw": 1.658569807730883,
                "pitch": 0.022629703980733495,
                "fov": 1.1438673478597468
            },
            "linkHotspots": [{
                    "yaw": 1.49484308227726,
                    "pitch": 0.4849629473508408,
                    "rotation": 0,
                    "target": "1-livingroom-kitchen",
                    "next": 0
                },
                {
                    "yaw": 2.6537617577390975,
                    "pitch": 0.8333597240671917,
                    "rotation": 0,
                    "target": "4-toilet",
                    "next": 0

                },
                {
                    "yaw": 0.9163362391070358,
                    "pitch": 0.5295004175284461,
                    "rotation": 0,
                    "target": "2-bedroom1",
                    "next": 0
                },
                {
                    "yaw": 2.1259148979186584,
                    "pitch": 0.651489946126933,
                    "rotation": 0,
                    "target": "3-bedroom2",
                    "next": 0
                }
            ],
            "perspectiveHotspots": [],
            "infoHotspots": []
        },
        {
            "id": "1-livingroom-kitchen",
            "name": "LivingRoom-Kitchen",
            "mapcontainer": "1",
            "x": "52%",
            "y": "55%",
            "videos": false,
            "levels": [{
                    "tileSize": 256,
                    "size": 256,
                    "fallbackOnly": true
                },
                {
                    "tileSize": 512,
                    "size": 512
                },
                {
                    "tileSize": 512,
                    "size": 1024
                },
                {
                    "tileSize": 512,
                    "size": 2048
                }
            ],
            "faceSize": 2048,
            "initialViewParameters": {
                "yaw": 1.5592023680906504,
                "pitch": 0.03226585840927321,
                "fov": 1.3785064270268044
            },
            "linkHotspots": [{
                    "yaw": 1.3521742566295405,
                    "pitch": 0.5059630660037122,
                    "rotation": 0,
                    "target": "0-entrance",
                    "next": 0
                },
                {
                    "yaw": 1.055704290025492,
                    "pitch": 0.5760447851049442,
                    "rotation": 0,
                    "target": "4-toilet",
                    "next": 0
                },
                {
                    "yaw": 2.5080237637288825,
                    "pitch": 0.6614908104881447,
                    "rotation": 0,
                    "target": "2-bedroom1",
                    "next": 0
                },
                {
                    "yaw": 0.7201336478892699,
                    "pitch": 0.725532852178647,
                    "rotation": 0,
                    "target": "3-bedroom2",
                    "next": 0
                }
            ],
            "perspectiveHotspots": [],
            "infoHotspots": []
        },
        {
            "id": "2-bedroom1",
            "name": "Master Bedroom",
            "mapcontainer": "1",
            "x": "80%",
            "y": "40%",
            "videos": false,
            "levels": [{
                    "tileSize": 256,
                    "size": 256,
                    "fallbackOnly": true
                },
                {
                    "tileSize": 512,
                    "size": 512
                },
                {
                    "tileSize": 512,
                    "size": 1024
                },
                {
                    "tileSize": 512,
                    "size": 2048
                }
            ],
            "faceSize": 2048,
            "initialViewParameters": {
                "yaw": 1.9438309154706683,
                "pitch": -0.007252632606428833,
                "fov": 1.4677056972055151
            },
            "linkHotspots": [{
                    "yaw": 2.2668145045695534,
                    "pitch": 0.18827612162833418,
                    "rotation": 0,
                    "target": "4-toilet",
                    "next": 0
                },
                {
                    "yaw": 2.005106719178759,
                    "pitch": 0.20283834091220143,
                    "rotation": 0,
                    "target": "3-bedroom2",
                    "next": 0
                },
                {
                    "yaw": 1.8795113460486164,
                    "pitch": 0.533194433387731,
                    "rotation": 0,
                    "target": "1-livingroom-kitchen",
                    "next": 0
                }
            ],
            "perspectiveHotspots": [],
            "infoHotspots": []
        },
        {
            "id": "3-bedroom2",
            "name": "Bed Room1",
            "mapcontainer": "1",
            "x": "25%",
            "y": "40%",
            "videos": false,
            "levels": [{
                    "tileSize": 256,
                    "size": 256,
                    "fallbackOnly": true
                },
                {
                    "tileSize": 512,
                    "size": 512
                },
                {
                    "tileSize": 512,
                    "size": 1024
                },
                {
                    "tileSize": 512,
                    "size": 2048
                }
            ],
            "faceSize": 2048,
            "initialViewParameters": {
                "yaw": 1.5116628055991583,
                "pitch": 0.02069812962156803,
                "fov": 1.3784828517604675
            },
            "linkHotspots": [{
                    "yaw": 1.3682232718721874,
                    "pitch": 0.09023509440016753,
                    "rotation": 0,
                    "target": "2-bedroom1",
                    "next": 0
                },
                {
                    "yaw": 1.3826622489716716,
                    "pitch": 0.5388915482581904,
                    "rotation": 0,
                    "target": "1-livingroom-kitchen",
                    "next": 0
                }
            ],
            "perspectiveHotspots": [],
            "infoHotspots": []
        },
        {
            "id": "4-toilet",
            "name": "Toilet",
            "mapcontainer": "1",
            "x": "33%",
            "y": "20%",
            "videos": false,
            "levels": [{
                    "tileSize": 256,
                    "size": 256,
                    "fallbackOnly": true
                },
                {
                    "tileSize": 512,
                    "size": 512
                },
                {
                    "tileSize": 512,
                    "size": 1024
                },
                {
                    "tileSize": 512,
                    "size": 2048
                }
            ],
            "faceSize": 2048,
            "initialViewParameters": {
                "yaw": 0.7720572846112006,
                "pitch": -0.0029347834580377707,
                "fov": 1.562700631287364
            },
            "linkHotspots": [{
                    "yaw": 1.953206878717996,
                    "pitch": 0.7429312034457141,
                    "rotation": 0,
                    "target": "0-entrance",
                    "next": 0
                },
                {
                    "yaw": 2.6465597341746534,
                    "pitch": 0.2831049566503978,
                    "rotation": 0,
                    "target": "2-bedroom1",
                    "next": 0
                }
            ],
            "perspectiveHotspots": [],
            "infoHotspots": []
        }
    ],
    "name": "KC009_Tower1-2_FLAT-M",
    "settings": {
        "mouseViewMode": "drag",
        "deviceOrientationEnabled": false,
        "autorotateEnabled": false,
        "fullscreenButton": true,
        "viewControlButtons": false
    }
};