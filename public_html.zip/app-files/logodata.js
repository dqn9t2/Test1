var LOGO_DATA = {
    "logos_breit": [],
    "logos_quad": [
        { "image": "logos/Baeckerchor_Zittau.png", "url": "https://www.baeckerchor.eu" },
        { "image": "logos/Bergfingen_logo-4c_01LGkl.png", "url": "https://www.bergfinken.de" },
        { "image": "logos/chor-budysin.jpg", "url": "http://www.chorbudysin.de" },
        { "image": "logos/Friedich_wolf.gif", "url": "https://www.chor-friedrich-wolf.com" },
        { "image": "logos/Kuort_Harthe.png", "url": "https://www.chor-des-kurortes-hartha.de" },
        { "image": "logos/chor_harmonie_bautzen.png", "url": "https://www.chor-harmonie-bautzen.de" },
        { "image": "logos/logo_gcp.gif", "url": "http://www.chor-pulsnitz.de" },
        { "image": "logos/Logo_Jazzchor-Dresden_normal-300x260.png", "url": "https://jazzchor-dresden.de" },
        { "image": "logos/Freier_Chor_Dresden.png", "url": "https://freier-chor-dresden.de" },
        { "image": "logos/Musikverein_Freital.png", "url": "http://www.musikverein-freital.de" },
        { "image": "logos/Nicode-Logo.png", "url": "https://www.nicode-chor.de" }
    ]
};